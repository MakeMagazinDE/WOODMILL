#c't Hacks Holzfr�se


Pl�ne als PDF und f�r **[DesignSpark Mechanical](http://www.designspark.com/deu/page/mechanical)**

Bema�ung aus editierbarem DesignSpark-Entwurf ersichtlich (Beschriftungsebenen einblenden!)

Es ist m�glich, die recht teuren Kugelwagen-Linearf�hrungen mit leichten Modifikationen (zus�tzliche Brettchen zur Erh�hung) durch die preiswerten DryLin-Gleitschienen Typ N in 27 und 40 mm Breite von [Igus](http://www.igus.de/wpck/1969/drylin_n) zu ersetzen (CAD-Daten anbei). Hierbei ist aber auf einen stabilen, verwindungssteifen Unterbau der Fr�se zu achten, da diese Gleitschienen im Unterschied zu den Stahlwellen weniger steif sind.

Aus technischen Gr�nden PDFs erst sp�ter online.

